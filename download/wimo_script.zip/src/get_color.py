from PIL import ImageGrab
import numpy as np


def get_color(x: int, y: int):
    return np.array(ImageGrab.grab())[y, x]


def rgb_to_hex(rgb: tuple):
    r = hex(rgb[0])[2:] if 4 == len(hex(rgb[0])) else f"0{hex(rgb[0])[2:]}"
    g = hex(rgb[1])[2:] if 4 == len(hex(rgb[1])) else f"0{hex(rgb[1])[2:]}"
    b = hex(rgb[2])[2:] if 4 == len(hex(rgb[2])) else f"0{hex(rgb[2])[2:]}"
    return f"#{r}{g}{b}"
