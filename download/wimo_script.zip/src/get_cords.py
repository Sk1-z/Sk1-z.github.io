import win32api as w32


def get_cords():
    return w32.GetCursorPos()
