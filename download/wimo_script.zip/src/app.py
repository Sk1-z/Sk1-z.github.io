import customtkinter as ctk
from .get_cords import get_cords
from .get_color import get_color, rgb_to_hex


class Window(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("225x300")
        self.title("Pixel Info")
        self.resizable(False, False)
        self.iconbitmap("WIMO.ico")
        # App variables
        self.mouse_X, self.mouse_Y = get_cords()
        self.mouse_rgb = get_color(self.mouse_X, self.mouse_Y)
        self.mouse_hex = rgb_to_hex(self.mouse_rgb)
        self.font = ctk.CTkFont("Consolas", 24)
        # Configure grids
        self.grid_columnconfigure(0, weight=1)
        # Draw widgets
        self.coord_X = ctk.CTkLabel(self, text="", font=self.font)
        self.coord_X.grid(row=0, column=0, pady=10)
        self.coord_Y = ctk.CTkLabel(self, text="", font=self.font)
        self.coord_Y.grid(row=1, column=0, pady=5)

        self.color_rect = ctk.CTkCanvas(self, height=50, width=100, bg=self.mouse_hex)
        self.color_rect.grid(row=2, column=0, pady=7.5)
        self.rgb = ctk.CTkLabel(self, text="", font=self.font)
        self.rgb.grid(row=3, column=0, pady=5)
        self.hex = ctk.CTkLabel(self, text="", font=self.font)
        self.hex.grid(row=4, column=0, pady=10)
        # Update
        self.update_cords()
        self.update_colors()

    def update_cords(self):
        self.mouse_X, self.mouse_Y = get_cords()
        self.coord_X.configure(True, text=f"mouse_X = {self.mouse_X}")
        self.coord_Y.configure(True, text=f"mouse_Y = {self.mouse_Y}")
        self.after(50, self.update_cords)

    def update_colors(self):
        self.mouse_rgb = get_color(self.mouse_X, self.mouse_Y)
        self.rgb.configure(
            True,
            text=f"RGB ({self.mouse_rgb[0]}, {self.mouse_rgb[1]}, {self.mouse_rgb[2]})",
        )
        self.mouse_hex = rgb_to_hex(self.mouse_rgb)
        self.hex.configure(True, text=f"{self.mouse_hex}")
        self.color_rect.configure(bg=self.mouse_hex)
        self.after(50, self.update_colors)
